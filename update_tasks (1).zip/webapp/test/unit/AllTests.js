sap.ui.define([
	"maz_renfe/update_tasks/test/unit/controller/Tareas.controller"
], function () {
	"use strict";
});