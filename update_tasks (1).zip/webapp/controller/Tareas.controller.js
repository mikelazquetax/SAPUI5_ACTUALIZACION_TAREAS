sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ushell/services/UserInfo",
	"sap/m/MessageBox",
	'jquery.sap.global',
	'sap/m/MessageToast'
], function (Controller, Filter, UserInfo, MessageBox, jquery, MessageToast) {
	"use strict";
	var user;

	return Controller.extend("maz_renfe.update_tasks.controller.Tareas", {
		onInit: function () {

			//Intentamos obtener el usuario conectado - hola
			try {
				var userInfo = new sap.ushell.services.UserInfo();
				user = userInfo.getId().toUpperCase();
			} catch (oError) {
				console.log("Error al recuperar usuario");
				user = 'S0019566339';
				console.log('hola' + user)
			}
			var that = this
			that.getView().setBusy(true)

			this.obtainData().then(function (apto) {

				console.log(apto)
				that.getView().setBusy(false)
			})

			var oInput = this.getView().byId("oInput")
			oInput.addEventDelegate({
				onAfterRendering: function () {
					var oInput = this.$().find('.sapMInputBaseInner');
					var oID = oInput[0].id;
					$('#' + oID).bind("cut copy", function (e) {
						e.preventDefault();
						alert('No se permite Copiar Textos')
						return false;
					});
				}
			}, oInput);
		},

		obtainData: function () {

			var oModelBackground = new sap.ui.model.json.JSONModel();
			var odataArray = [];
			var that = this;
			var oDatax = this.getView().getModel("trayectoria")
			that.getView().setBusy(true)
			return new Promise((resolve, reject) => {
				/*			oDatax.read("/Background_InsideWorkExperience", {
								filters: [
									new Filter("userId", "EQ", user)
								],
								success: function (oData, response) {
									var odataResult = oData.results;
									odataArray.push(odataResult);
									oModelBackground.setData(odataResult)
									that.getView().setModel(oModelBackground, "backgrounds")
									that.getView().setBusy(false)
									resolve(true)
								},
								error: function (oError) {
									console.log(oError)
								//	that.getView().setBusy(false)
								}
							})*/
				var path = '/odata/v2/Background_InsideWorkExperience?$filter=userId%20eq%20%27' + user + '%27'
				$.ajax({
					url: path,
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					success: function (oData, response) {
						console.log('ok')
						var odataResult = oData.d.results;
						odataArray.push(odataResult);

						odataResult.forEach((registro) => {

							registro.startDate = new Date(parseInt(registro.startDate.split('(')[1].split(')')[0]))
							registro.endDate = new Date(parseInt(registro.endDate.split('(')[1].split(')')[0]))

						})

						oModelBackground.setData(odataResult)
						that.getView().setModel(oModelBackground, "backgrounds")
						that.getView().setBusy(false)

						//	that.getView().getModel('backgrounds').getData()[0].startDate
						resolve(true)
					},
					error: function (oError) {

					}
				})

			})
		},

		count4000: function (evento) {

			var oJSONModelError = new sap.ui.model.json.JSONModel({
				valueError: "Information",
				valueText: "Entrada OK"
			});

			var oJSONModelVisibilidad = new sap.ui.model.json.JSONModel({
				valueVisible: true,
			});

			this.getView().setModel(oJSONModelError, "jsonVError");
			this.getView().setModel(oJSONModelError, "jsonVis");

			var longitud = evento.getParameters().value.length
			if (longitud > 4000) {
				var valorEstate = this.getView().getModel("jsonVError").getData()
				valorEstate.valueError = 'Error'
				valorEstate.valueText = 'Longitud mayor a 4000 caracteres'
				var modeloEstate = this.getView().getModel("jsonVError").setData(valorEstate)

				var valorBton = this.getView().getModel("jsonVis").getData()
				valorBton.valueVisible = false
				var modeloVisible = this.getView().getModel("jsonVis").setData(valorBton)

			}

		},

		onSave: function (evento) {
			var path = '/odata/v2/Background_InsideWorkExperience('
			var datoActualizados = this.getView().getModel('backgrounds').getData();
			var obj = {
				"functions": 'cc'
			};

			/*			var updatedRecord = {
							"functions": '',
						};
						
						datoActualizados.forEach((datoactualizado)=>{
							var pathtoUpdate = path + '(' + 'backgroundElementId=' + datoactualizado.backgroundElementId + 'L' + ',' + 'userId='+ `'` + datoactualizado.userId + `'` + ')'
							updatedRecord.functions = datoactualizado.functions
							
							
							this.getView().getModel('trayectoria').UPDATE(pathtoUpdate, updatedRecord, {
							success: function () {
								
								MessageBox.success("Cambios Guardados");
							},
							error: function () {
								MessageBox.error("Error en el guardado de datos");
							}
						})
						})*/
			datoActualizados.forEach((datoactualizado) => {

				//datoactualizado.lastModifiedDate = new Date().getTime() 
				//datoactualizado.startDate = '2022-08-31T12:08:13'
				//datoactualizado.endDate = '2022-09-21T02:00:00'
				/*		 datoactualizado.startDate = '/' + 'Date' + '(' + datoactualizado.startDate.getTime() + ')' + '/'
						 datoactualizado.endDate =  '/' + 'Date' + '(' + datoactualizado.endDate.getTime() + ')' + '/' */
				datoactualizado.endDate = '/' + 'Date(' + new Date(datoactualizado.endDate).getTime() + ')/'
				datoactualizado.startDate = '/' + 'Date(' + new Date(datoactualizado.startDate).getTime() + ')/'

				var datox = {
					"changeReason": datoactualizado.changeReason,
					"collaborators": datoactualizado.collaborators,
					"endDate": datoactualizado.endDate,
					"functionalArea": datoactualizado.functionalArea,

					"functions": datoactualizado.functions,
					"generalManagement": datoactualizado.generalManagement,
					"higherPosition": datoactualizado.higherPosition,
					"jobCategory": datoactualizado.jobCategory,
					"jobPosition": datoactualizado.jobPosition,
					"organizationalArea": datoactualizado.organizationalArea,
					"personalCategory": datoactualizado.personalCategory,
					"personalDiv": datoactualizado.personalDiv,
					"personalSubDiv": datoactualizado.personalSubDiv,
					"provPersonalSubDiv": datoactualizado.provPersonalSubDiv,
					"startDate": datoactualizado.startDate,

				}

				//			var pathtoUpdate = path + '(' + 'backgroundElementId=' + datoactualizado.backgroundElementId + 'L' + ',' + 'userId='+ `'` + datoactualizado.userId + `'` + ')'
				$.ajax({
					url: path + 'backgroundElementId=' + datoactualizado.backgroundElementId + 'L' + ',' + 'userId=' + `'` + datoactualizado.userId +
						`'` + ')',
					//url: "/odata/v2/Background_InsideWorkExperience(backgroundElementId=360372L,userId='S0019566339')",
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					success: function (results, status, response) {
						var header_xcsrf_token = response.getResponseHeader("x-csrf-token");
						var oHeaders = {
							"x-csrf-token": header_xcsrf_token,
							"Accept": "application/json",
							"Content-Type": "application/json; charset=utf-8",
							"x-http-method": "MERGE"
						};

						$.ajax({
							url: path + 'backgroundElementId=' + datoactualizado.backgroundElementId + 'L' + ',' + 'userId=' + `'` + datoactualizado
								.userId + `'` + ')',
							//url: "/odata/v2/Background_InsideWorkExperience(backgroundElementId=360372L,userId='S0019566339')",
							type: "PUT",
							data: JSON.stringify(datox),
							// dataType: "json",
							headers: oHeaders,
							async: true,
							success: function (data, status2, response2) {
								sap.m.MessageBox.success('Tareas actualizadas', {
									onClose: function (actions) {
										if (actions == 'OK') {
											location.reload()
										}
									}
								});

							},
							error: function (oError) {
								console.log('hay error')
							}
						});

					}

				})
			})

		},

	});
});